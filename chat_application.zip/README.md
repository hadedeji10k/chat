# electron-vite-boilerplate
1. First install dependencies: ```npm install``` </br>
2. Then to run locally (development) run: ```npm run dev``` This command will start the electron app <br/>
3. To build for a release: ```npm run build```